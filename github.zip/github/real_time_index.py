import json
import csv
import re
from stemming.porter2 import stem
from nltk import SnowballStemmer
import gc

def loadfile():
    filelist = ['title_index.json', 'title_proximity.json', 'ingredients_index.json', 'ingredients_proximity.json',
                'instructions_index.json', 'instructions_proximity.json', 'alldoc_index.json', 'alldoc_proximity.json','title.json', 'ingredients.json', 'instructions.json', 'alldoc.json']

    docno = []
    ti = {}
    tp = {}
    ii = {}
    ip = {}
    iii = {}
    iip = {}
    ai = {}
    at = {}
    title = []
    ingredients = []
    instructions = []
    alldoc =[]
    namelist = [ti, tp, ii, ip, iii, iip, ai, at,title, ingredients, instructions, alldoc]
    for i in range(len(namelist)):
        with open(filelist[i], 'r') as f:
            namelist[i] = json.load(f)

    file = open('data_index.txt', 'r')
    for line in file.readlines():
        line = line.strip('\n')
        docno.append(int(line))

    file.close()
    return namelist[0], namelist[1], namelist[2], namelist[3], \
           namelist[4], namelist[5], namelist[6], namelist[7], namelist[8], namelist[9], namelist[10],namelist[11],docno

# Pre-processes text
def preprocess(dataset):
    stopw=[]
    with open('frenchST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('englishST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('portugueseST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    new = []
    fr = SnowballStemmer("french")
    pt = SnowballStemmer('portuguese')
    for content in dataset:
        new_content = content.lower()
        new_content = re.split('\W', new_content)
        new_content = list(filter(lambda x: not x == '', new_content))
        new_content = [pt.stem(fr.stem(stem(word))) for word in new_content if pt.stem(fr.stem(stem(word))) not in stopw]
        new.append(new_content)
    return new

# load data
def load_new(donum, alldoc):
    new_docid = []
    new_title = []
    new_ingredients = []
    new_instructions = []
    new_alldoc = []
    with open('new.csv', 'r', encoding='unicode_escape') as f:
        count = 0
        num = 1+ donum
        reader = csv.reader(f)
        for row in reader:
            if count != 0:
                new_docid.append(num)
                num += 1
                new_title.append(row[0])
                new_ingredients.append(row[1])
                new_instructions.append(row[2])
            count += 1
    title = preprocess(new_title)
    ingredients = preprocess(new_ingredients)
    instructions = preprocess(new_instructions)
    for num in range(len(title)):
        alldoc.append(title[num] + ingredients[num] + instructions[num])
    #print(new_ingredients)
    return title, ingredients, instructions, alldoc, new_docid

def create_new_index(ori_index,ori_proximity,data, docno):
    print("!")
    document_map = dict(zip(docno, data))
    index = ori_index
    proximity = ori_proximity
    for id, document in document_map.items():
        words = document
        for word in words:
            pos = words.index(word)
            if word not in index.keys():
                index[word] = {}
                proximity[word] = {}
            if id not in index[word].keys():
                index[word][id] = 0
                # print(word)
                proximity[word][id] = []
            index[word][id] += 1
            proximity[word][id].append(pos)

    print("/!")
    return index, proximity

def writefile(ti, tp, ii, ip, iii, iip, ai, at, docno,title, ingredients, instructions, alldoc):
    namelist = [ti, tp, ii, ip, iii, iip, ai, at,title, ingredients, instructions, alldoc]
    filelist = ['title_index.json','title_proximity.json','ingredients_index.json','ingredients_proximity.json',
                'instructions_index.json','instructions_proximity.json','alldoc_index.json','alldoc_proximity.json','title.json', 'ingredients.json', 'instructions.json', 'alldoc.json']

    for i in range(len(namelist)):
        jsObj = json.dumps(namelist[i])
        fileObject = open(filelist[i], 'w')
        fileObject.write(jsObj)
        fileObject.close()



def add_new_index():

    alldoc = loadfile2('alldoc.json')
    docno=[]
    file = open('data_index.txt', 'r')
    for line in file.readlines():
        line = line.strip('\n')
        docno.append(int(line))
    file.close()

    new_title, new_ingredients, new_instructions, new_alldoc, new_docno = load_new(len(docno), alldoc)

    docno.extend(new_docno)
    file = open('data_index.txt', 'w')
    for fp in docno:
        file.write(str(fp))
        file.write('\n')
    file.close()
    del docno
    gc.collect()
    print("删除docno成功")

    #alldoc
    #1
    alldoc.extend(new_alldoc)
    writefile(alldoc, "alldoc.json")
    del alldoc
    gc.collect()
    #2
    alldoc_index = loadfile1('alldoc_index.json')
    alldoc_proximity = loadfile1('alldoc_proximity.json')
    alldoc_index, alldoc_proximity = create_new_index(alldoc_index, alldoc_proximity, new_alldoc, new_docno)
    writefile(alldoc_index, "alldoc_index.json")
    writefile(alldoc_proximity, "alldoc_proximity.json")
    del alldoc_index,alldoc_proximity
    gc.collect()
    print("删除alldoc")

    #title
    #process 1
    title_index = loadfile1('title_index.json')
    title_proximity=loadfile1('title_proximity.json')
    title_index, title_proximity = create_new_index(title_index, title_proximity,new_title, new_docno)
    writefile(title_index, "title_index.json")
    writefile(title_proximity, "title_proximity.json")
    del title_index,title_proximity
    gc.collect()
    # process 2
    title = loadfile2('title.json')
    title.extend(new_title)
    writefile(title, "title.json")
    del title
    gc.collect()
    print("删除title")

    #ingredients
    # process 1
    ingredients_index = loadfile1('ingredients_index.json')
    ingredients_proximity = loadfile1('ingredients_proximity.json')
    ingredients_index, ingredients_proximity = create_new_index(ingredients_index, ingredients_proximity,new_ingredients, new_docno)
    writefile(ingredients_index, "ingredients_index.json")
    writefile(ingredients_proximity, "ingredients_proximity.json")
    del ingredients_index, ingredients_proximity
    gc.collect()
    # process 2
    ingredients = loadfile2('ingredients.json')
    ingredients.extend(new_ingredients)
    writefile(ingredients, "ingredients.json")
    del ingredients
    gc.collect()
    print("删除ingredients")

    #instruction
    #process 1
    instructions_index = loadfile1('instructions_index.json')
    instructions_proximity = loadfile1('instructions_proximity.json')
    instructions_index, instructions_proximity = create_new_index(instructions_index, instructions_proximity,new_instructions, new_docno)
    writefile(instructions_index, "instructions_index.json")
    writefile(instructions_proximity, "instructions_proximity.json")
    del instructions_index,instructions_proximity
    gc.collect()
    # process 2
    instructions = loadfile2('instructions.json')
    instructions.extend(new_instructions)
    writefile(instructions, "instructions.json")
    del instructions
    gc.collect()
    print("删除instructions")









