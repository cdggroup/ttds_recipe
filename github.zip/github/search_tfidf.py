import csv
import re
import math
import nltk
import json
from stemming.porter2 import stem
from nltk import SnowballStemmer
nltk.download('averaged_perceptron_tagger')
#propreccess query
def parser(content):
    stopw=[]
    with open('frenchST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('englishST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('portugueseST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    pt = SnowballStemmer('portuguese')
    fr = SnowballStemmer("french")
    new = []
    pos_tag = []
    content = content.lower()
    content = re.split('\W', content)
    content = list(filter(lambda x: not x == '', content))
    postag_query = nltk.pos_tag(content)
    for i in range(len(content)):
        new_w = pt.stem(fr.stem(stem(content[i])))
        if new_w not in stopw:
            new.append(new_w)
            pos_tag.append(postag_query[i][1])
    return new, pos_tag

# function to compute tfidf score
def compute_tfidf_score(text, index, num,docno):
    scorelist = []
    N = num
    for i in range(num):
        scorelist.append([docno[i], 0])
    for word in text:
        if word in index.keys():
            df = len(index[word])
            for id in index[word]:
                tf = index[word][id]
                score = (1+math.log10(tf))*math.log10(N/df)
                addscore = [j for j in scorelist if j[0] == int(id)]
                idx = scorelist.index(addscore[0])
                scorelist[idx][1] += score

    return scorelist

def compute_tfidf_score(text, index, num,docno):
    scorelist = {}
    N = num
    for word in text:
        if word in index.keys():
            df = len(index[word])
            for id in index[word]:
                tf = index[word][id]
                score = (1+math.log10(tf))*math.log10(N/df)
                if id not in scorelist.keys():
                    scorelist[id]=0
                scorelist[id] +=score

    return scorelist

#calculate the score after query expansion
def queryexpansion_score(output, data, index, N,docno):
    expansion = []
    if output:
        output = sorted(output.items(), key = lambda kv:(kv[1], kv[0]),reverse=True)
        top_doc = [str(x[0]) for x in output]
        # print(top_doc)
        n_d = 1
        n_d_doc = []
        content = []
        for i in range(n_d):
            n_d_doc.append(top_doc[i])
        for docid in n_d_doc:
            for word in data[int(docid)]:
                content.append(word)
        pos = 0
        dic = {}
        for term in content:
            pos += 1
            if (term in dic):
                dic[term].append(pos)
            else:
                dic[term] = []
                dic[term].append(pos)
        dic = dict(sorted(dic.items(), key=lambda x: x[0]))
        Scores = {}
        for term in dic:
            if term in index.keys():
                tf = len(dic[term])
                df = len(index[term])
                w = tf * math.log10(N / df)
                Scores[term] = w
        Scores = sorted(Scores.items(), key=lambda x: x[1], reverse=True)

        if len(Scores) <= 5:
            for i in range(len(Scores)):
                expansion.append(Scores[i][0])
        else:
            Scores = Scores[0:5]
            for i in range(5):
                expansion.append(Scores[i][0])

    return compute_tfidf_score(expansion, index, N,docno)

#combine query score with expansion score
def combinescore(output1,output2):
    output = output1
    for id in output2.keys():
        if id not in output:
            output[id] = 0
        output[id] += output2[id]
    return output

#function to search query in title, ingredient, instructions and whole doc
def get_score(query, title_index, ingredients_index, instructions_index, num,docno):
    title_out = compute_tfidf_score(query, title_index, num,docno)
    ingre_out = compute_tfidf_score(query, ingredients_index, num,docno)
    instr_out = compute_tfidf_score(query, instructions_index, num,docno)
    global_out = instr_out
    for id in title_out:
        if id not in global_out.keys():
            global_out[id] = 0
        global_out[id]+=10*title_out[id]
    for id in ingre_out:
        if id not in global_out.keys():
            global_out[id] = 0
        global_out[id]+=5*ingre_out[id]
    return title_out,ingre_out,instr_out,global_out

#两个term在一个doc的距离是否小于d
def dis(arr1,arr2,d):
    for i in range(len(arr1)):
        for j in range(len(arr2)):
            if abs(arr1[i]-arr2[j]) <= d:
                return True
    return False

# promixity sreach 返回一个包含符合要求的doc的list
def pro(term1,term2,d,proximity):
    docname = []
    if term1 in proximity.keys() and term2 in proximity.keys():
        t1 = proximity[term1]
        t2 = proximity[term2]
        for key in t1.keys() & t2.keys():
            if dis(t1[key],t2[key],d):
                docname.append(key)
    return docname

#临近搜索后符合要求的文档分数*2
def getprodoc(query,postag,d,proximity,scorelist):
    docname = []
    for i in range(len(postag)-1):
        if postag[i] == 'VB'or postag[i] == 'VBD' or postag[i] == 'VBG' or postag[i] == 'VBN'or postag[i] == 'VBP'or postag[i] == 'VBZ':
            if postag[i+1] =='NN' or postag[i+1] =='NNS' or postag[i+1] =='NNP' or postag[i+1] =='NNPS':
                docname.extend(pro(query[i],query[i+1],d,proximity))
    if docname:
        for prodoc in docname:
            scorelist[prodoc] = scorelist[prodoc]*2
    scorelist = sorted(scorelist.items(), key = lambda kv:(kv[1], kv[0]),reverse=True)
    return scorelist

def loadfile():
    filelist = ['title_index.json', 'title_proximity.json', 'ingredients_index.json', 'ingredients_proximity.json',
                'instructions_index.json', 'instructions_proximity.json', 'alldoc_index.json', 'alldoc_proximity.json','title.json', 'ingredients.json', 'instructions.json', 'alldoc.json']

    docno = []
    ti = {}
    tp = {}
    ii = {}
    ip = {}
    iii = {}
    iip = {}
    ai = {}
    at = {}
    title = []
    ingredients = []
    instructions = []
    alldoc =[]
    namelist = [ti, tp, ii, ip, iii, iip, ai, at,title, ingredients, instructions, alldoc]
    for i in range(len(namelist)):
        with open(filelist[i], 'r') as f:
            namelist[i] = json.load(f)

    file = open('data_index.txt', 'r')
    for line in file.readlines():
        line = line.strip('\n')
        docno.append(int(line))

    file.close()
    return namelist[0], namelist[1], namelist[2], namelist[3], \
           namelist[4], namelist[5], namelist[6], namelist[7], namelist[8], namelist[9], namelist[10],namelist[11],docno



# print(getresult("ginger","title"))