import re
import math
import nltk
import json
from stemming.porter2 import stem
from nltk import SnowballStemmer

#propreccess query
def parser(content):
    stopw=[]
    with open('frenchST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('englishST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('portugueseST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    pt = SnowballStemmer('portuguese')
    fr = SnowballStemmer("french")
    new = []
    pos_tag = []
    content = content.lower()
    content = re.split('\W', content)
    content = list(filter(lambda x: not x == '', content))
    postag_query = nltk.pos_tag(content)
    for i in range(len(content)):
        new_w = pt.stem(fr.stem(stem(content[i])))
        if new_w not in stopw:
            new.append(new_w)
            pos_tag.append(postag_query[i][1])
    return new, pos_tag

#compute BM25 score
def BM25(text,index,document_map,num,docno):
    scorelist = {}
    N = num
    avg_dl = 0
    for i in range(len(document_map)):
        avg_dl += len(document_map[i])
    avg_dl = avg_dl/N
    k1 = 2
    b = 0.75

    for word in text:
        if word in index.keys():
            df = len(index[word])#包含这个词的文章数
            for id in index[word]:
                f = index[word][id]#该词出现在该文章的次数
                dl = len(document_map[int(id)])#该文章长度
                w = math.log10((N-df+0.5)/(df+0.5))
                k = k1*(1-b+b*dl/avg_dl)
                r = ((f*(k1+1))/(f+k))
                score = w*r
                if id not in scorelist.keys():
                    scorelist[id]=0
                scorelist[id] +=score

    return scorelist

##calculate the score after query expansion
def queryexpansion_score(output, data, index, N,docno):
    output = sorted(output.items(), key = lambda kv:(kv[1], kv[0]),reverse=True)
    top_doc = [str(x[0]) for x in output]
    n_d = 1
    n_d_doc = []
    content = []
    for i in range(n_d):
        n_d_doc.append(top_doc[i])
    for docid in n_d_doc:
        for word in data[int(docid)-1]:
            content.append(word)
    pos = 0
    dic = {}
    for term in content:
        pos += 1
        if (term in dic):
            dic[term].append(pos)
        else:
            dic[term] = []
            dic[term].append(pos)
    dic = dict(sorted(dic.items(), key=lambda x: x[0]))
    Scores = {}
    for term in dic:
        tf = len(dic[term])
        df = len(index[term])
        w = tf * math.log10(N / df)
        Scores[term] = w
    Scores = sorted(Scores.items(), key=lambda x: x[1], reverse=True)
    expansion = []
    if len(Scores) <= 5:
        for i in range(len(Scores)):
            expansion.append(Scores[i][0])
    else:
        Scores = Scores[0:5]
        for i in range(5):
            expansion.append(Scores[i][0])

    return BM25(expansion,index,data,N,docno)

#combine query score with expansion score
def combinescore(output1,output2):
    output = output1
    for id in output2.keys():
        if id not in output:
            output[id] = 0
        output[id] += output2[id]
    return output

#function to calculate bm25 score in title, ingredient, instructions and whole doc
def get_score(query, title_index, ingredients_index, instructions_index, title,ingredients,instructions,num,docno):
    title_out = BM25(query, title_index,title, num,docno)
    ingre_out = BM25(query, ingredients_index, ingredients, num,docno)
    instr_out = BM25(query, instructions_index, instructions, num,docno)
    global_out = instr_out
    for id in title_out:
        if id not in global_out.keys():
            global_out[id] = 0
        global_out[id]+=10*title_out[id]
    for id in ingre_out:
        if id not in global_out.keys():
            global_out[id] = 0
        global_out[id]+=5*ingre_out[id]
    return title_out,ingre_out,instr_out,global_out

#两个term在一个doc的距离是否小于d
def dis(arr1,arr2,d):
    for i in range(len(arr1)):
        for j in range(len(arr2)):
            if abs(arr1[i]-arr2[j]) <= d:
                return True
    return False

# promixity sreach 返回一个包含符合要求的doc的list
def pro(term1,term2,d,proximity):
    docname = []
    if term1 in proximity.keys() and term2 in proximity.keys():
        t1 = proximity[term1]
        t2 = proximity[term2]
        for key in t1.keys() & t2.keys():
            if dis(t1[key],t2[key],d):
                docname.append(key)
    return docname

#临近搜索后符合要求的文档分数*2
def getprodoc(query,postag,d,proximity,scorelist):
    docname = []
    for i in range(len(postag)-1):
        if postag[i] == 'VB'or postag[i] == 'VBD' or postag[i] == 'VBG' or postag[i] == 'VBN'or postag[i] == 'VBP'or postag[i] == 'VBZ':
            if postag[i+1] =='NN' or postag[i+1] =='NNS' or postag[i+1] =='NNP' or postag[i+1] =='NNPS':
                docname.extend(pro(query[i],query[i+1],d,proximity))
    if docname:
        for prodoc in docname:
            scorelist[prodoc] = scorelist[prodoc]*2
    scorelist = sorted(scorelist.items(), key = lambda kv:(kv[1], kv[0]),reverse=True)
    return scorelist

def loadfile():
    filelist = ['title_index.json', 'title_proximity.json', 'ingredients_index.json', 'ingredients_proximity.json',
                'instructions_index.json', 'instructions_proximity.json', 'alldoc_index.json', 'alldoc_proximity.json','title.json', 'ingredients.json', 'instructions.json', 'alldoc.json']

    docno = []
    ti = {}
    tp = {}
    ii = {}
    ip = {}
    iii = {}
    iip = {}
    ai = {}
    at = {}
    title = []
    ingredients = []
    instructions = []
    alldoc =[]
    namelist = [ti, tp, ii, ip, iii, iip, ai, at,title, ingredients, instructions, alldoc]
    for i in range(len(namelist)):
        with open(filelist[i], 'r') as f:
            namelist[i] = json.load(f)

    file = open('data_index.txt', 'r')
    for line in file.readlines():
        line = line.strip('\n')
        docno.append(int(line))

    file.close()
    return namelist[0], namelist[1], namelist[2], namelist[3], \
           namelist[4], namelist[5], namelist[6], namelist[7], namelist[8], namelist[9], namelist[10],namelist[11],docno

def getresult(text,user_option):
    title_index, title_proximity,ingredients_index, ingredients_proximity,instructions_index, instructions_proximity,alldoc_index, alldoc_proximity,title, ingredients, instructions, alldoc,docno = loadfile()
    donum = len(docno)


    query,postag = parser(text)

    title_score,ingre_score,instr_score,global_score = get_score(query,title_index,ingredients_index,instructions_index,title,ingredients,instructions,donum,docno)

    title_expansion_score = queryexpansion_score(title_score,title,title_index,donum,docno)
    ingre_expansion_score = queryexpansion_score(ingre_score,ingredients,ingredients_index,donum,docno)
    instr_expansion_score = queryexpansion_score(instr_score,instructions,instructions_index,donum,docno)
    global_expansion_score = queryexpansion_score(global_score,alldoc,alldoc_index,donum,docno)

    options = ['title', 'ing', 'ins', 'global']

    option = user_option
    if option == 'title':
        output = getprodoc(query,postag,3,title_proximity,combinescore(title_score,title_expansion_score))
    elif option == 'ing':
        output = getprodoc(query,postag,3,ingredients_proximity,combinescore(ingre_score,ingre_expansion_score))
    elif option == 'ins':
        output = getprodoc(query,postag,3,instructions_proximity,combinescore(instr_score,instr_expansion_score))
    else:
        output = getprodoc(query,postag,3,alldoc_proximity,combinescore(global_score,global_expansion_score))

    res = []
    for i in range(20):
        res.append(output[i][0])

    return res

print(getresult("ginger","title"))


