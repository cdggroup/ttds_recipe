import csv
import re
import json
from stemming.porter2 import stem
from nltk import SnowballStemmer

# Pre-processes text
def preprocess(dataset):
    stopw=[]
    with open('frenchST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('englishST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    with open('portugueseST.txt', 'r',encoding='unicode_escape') as f:
        for line in f:
            for word in line.split():
                stopw.append(word)
    f.close()
    new = []
    fr = SnowballStemmer("french")
    pt = SnowballStemmer('portuguese')
    for content in dataset:
        new_content = content.lower()
        new_content = re.split('\W', new_content)
        new_content = list(filter(lambda x: not x == '', new_content))
        new_content = [pt.stem(fr.stem(stem(word))) for word in new_content if pt.stem(fr.stem(stem(word))) not in stopw]
        new.append(new_content)
    return new

# load data
def load():
    docid = []
    title = []
    ingredients = []
    instructions = []
    alldoc = []
    with open('test.csv', 'r') as f:
        count = 0
        num = 1
        reader = csv.reader(f)
        for row in reader:
            if count != 0:
                docid.append(num)
                num += 1
                title.append(row[0])
                ingredients.append(row[1])
                instructions.append(row[2])
            count += 1
    title = preprocess(title)
    ingredients = preprocess(ingredients)
    instructions = preprocess(instructions)
    for num in range(len(title)):
        alldoc.append(title[num] + ingredients[num] + instructions[num])
    return title, ingredients, instructions, alldoc, docid

def create_index(data, docno):
    document_map = dict(zip(docno, data))
    index = {}
    proximity = {}
    for id, document in document_map.items():
        words = document
        for word in words:
            pos = words.index(word)
            if word not in index.keys():
                index[word] = {}
                proximity[word] = {}
            if id not in index[word].keys():
                index[word][id] = 0
                proximity[word][id] = []
            index[word][id] += 1
            proximity[word][id].append(pos)
    return index, proximity

def writefile(ti, tp, ii, ip, iii, iip, ai, at, docno,title, ingredients, instructions, alldoc):
    namelist = [ti, tp, ii, ip, iii, iip, ai, at,title, ingredients, instructions, alldoc]
    filelist = ['title_index.json','title_proximity.json','ingredients_index.json','ingredients_proximity.json',
                'instructions_index.json','instructions_proximity.json','alldoc_index.json','alldoc_proximity.json','title.json', 'ingredients.json', 'instructions.json', 'alldoc.json']

    for i in range(len(namelist)):
        jsObj = json.dumps(namelist[i])
        fileObject = open(filelist[i], 'w')
        fileObject.write(jsObj)
        fileObject.close()

    file = open('data_index.txt', 'w')
    for fp in docno:
        file.write(str(fp))
        file.write('\n')
    file.close()

if __name__ == '__main__':
    fr = SnowballStemmer("french")
    pt = SnowballStemmer('portuguese')
    title, ingredients, instructions, alldoc, docno = load()
    donum = len(docno)
    alldoc_index, alldoc_proximity = create_index(alldoc, docno)
    title_index, title_proximity = create_index(title, docno)
    ingredients_index, ingredients_proximity = create_index(ingredients, docno)
    instructions_index, instructions_proximity = create_index(instructions, docno)

    writefile(title_index, title_proximity,ingredients_index, ingredients_proximity,instructions_index, instructions_proximity,alldoc_index, alldoc_proximity,docno,title, ingredients, instructions, alldoc)

