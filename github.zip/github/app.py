from flask import Flask, render_template, request
from search_tfidf import parser,get_score,queryexpansion_score,getprodoc,combinescore
import pandas as pd
import sched
import time
from search_tfidf import loadfile


app = Flask(__name__)
schedule = sched.scheduler(time.time, time.sleep)
global page
# df_all = pd.read_csv('./recipes.csv')
# title_index, title_proximity, ingredients_index, ingredients_proximity, instructions_index, instructions_proximity, alldoc_index, alldoc_proximity, title, ingredients, instructions, alldoc, docno = loadfile()
df_new = pd.read_csv('./new.csv')

def getresult(text,user_option):

    donum = len(docno)
    query,postag = parser(text)
    title_score,ingre_score,instr_score,global_score= get_score(query,title_index,ingredients_index,instructions_index,donum,docno)
    title_expansion_score = queryexpansion_score(title_score,title,title_index,donum,docno)
    ingre_expansion_score = queryexpansion_score(ingre_score,ingredients,ingredients_index,donum,docno)
    instr_expansion_score = queryexpansion_score(instr_score,instructions,instructions_index,donum,docno)
    global_expansion_score = queryexpansion_score(global_score,alldoc,alldoc_index,donum,docno)

    options = ['title', 'ing', 'ins', 'global']

    option = user_option
    if option == 'title':
        output = getprodoc(query,postag,3,title_proximity,combinescore(title_score,title_expansion_score))
    elif option == 'ing':
        output = getprodoc(query,postag,3,ingredients_proximity,combinescore(ingre_score,ingre_expansion_score))
    elif option == 'ins':
        output = getprodoc(query,postag,3,instructions_proximity,combinescore(instr_score,instr_expansion_score))
    else:
        output = getprodoc(query,postag,3,alldoc_proximity,combinescore(global_score,global_expansion_score))

    res = []
    for i in range(len(output)):
        res.append(int(output[i][0]))
    return res

@app.route('/')
def main():

    titles_new = df_new['title'].to_list()
    ingres_new = df_new['ingredients'].to_list()
    for i in range(len(ingres_new)):
        ingres_new[i] = ingres_new[i].replace('\', \'', '\n')
        ingres_new[i] = ingres_new[i].replace('[', '')
        ingres_new[i] = ingres_new[i].replace(']', '')
        ingres_new[i] = ingres_new[i].replace('\'', '')

    instrs_new = df_new['instructions'].to_list()
    images_new = df_new['image'].to_list()
    links_new = df_new['links'].to_list()
    docno = []
    for i in range(len(titles_new)):
        docno.append('num'+str(i + 1))

    return render_template('content.html', docno=docno, title=titles_new, ingres=ingres_new, instrs=instrs_new, images=images_new, links=links_new, length=range(len(titles_new)),
                           error=True)


@app.route('/search/', methods=['POST'])
def search():
    try:
        global keys
        global value
        global list
        global resultlen
        global showlen

        keys = request.form['key_words']
        value = request.values.get('order')
        if keys:
            list = getresult(keys, value)
        else:
            return render_template('no-result.html', error=True)

        title_rs=[]
        ingres_rs=[]
        instrs_rs=[]
        images_rs=[]
        links_rs=[]
        docno_rs=[]
        for m in list:
            title_rs.append(df_all['title'].iloc[m-1])
            ingres_rs.append(df_all['ingredients'].iloc[m-1])
            instrs_rs.append(df_all['instructions'].iloc[m - 1])
            images_rs.append(df_all['image'].iloc[m - 1])
            links_rs.append(df_all['links'].iloc[m - 1])
            docno_rs.append('num' + str( m ))
        for i in range(len(ingres_rs)):
            ingres_rs[i] = ingres_rs[i].replace('\', \'', '\n')
            ingres_rs[i] = ingres_rs[i].replace('[', '')
            ingres_rs[i] = ingres_rs[i].replace(']', '')
            ingres_rs[i] = ingres_rs[i].replace('\'', '')

        if list:
            resultlen = len(list)
            if len(list)>900:
                title_rs = title_rs[0:900]
                ingres_rs = ingres_rs[0:900]
                instrs_rs = instrs_rs[0:900]
                images_rs = images_rs[0:900]
                links_rs = links_rs[0:900]
                showlen=900
                list=list[0:900]
                page,new_list=cut_page(list)
            else:
                showlen=resultlen
                page, new_list = cut_page(list)

            return render_template('content.html', docno=docno_rs, title=title_rs, ingres=ingres_rs, instrs=instrs_rs,
                                   images=images_rs, links=links_rs, error=False, length=range(len(new_list[0])), resultlen=resultlen,showlen=showlen,page=page,page_no=1, keys=keys)
        else:
            return render_template('no-result.html', error=False)

    except:
        return render_template('error.html',error=False)

def cut_page(list):
    page = []
    for i in range(1, (len(list) // 90)):
        page.append(i)

    global new_list
    new_list = [list[i:i + 90] for i in range(0, len(list), 90)]
    return page,new_list


@app.route('/search/<page_no>',methods=['GET'])
def change_page(page_no):


    try:
        title_rs = []
        ingres_rs = []
        instrs_rs = []
        images_rs = []
        links_rs = []
        docno_rs = []
        for m in list:
            title_rs.append(df_all['title'].iloc[m - 1])
            ingres_rs.append(df_all['ingredients'].iloc[m - 1])
            instrs_rs.append(df_all['instructions'].iloc[m - 1])
            images_rs.append(df_all['image'].iloc[m - 1])
            links_rs.append(df_all['links'].iloc[m - 1])
            docno_rs.append('num' + str(m))
        for i in range(len(ingres_rs)):
            ingres_rs[i] = ingres_rs[i].replace('\', \'', '\n')
            ingres_rs[i] = ingres_rs[i].replace('[', '')
            ingres_rs[i] = ingres_rs[i].replace(']', '')
            ingres_rs[i] = ingres_rs[i].replace('\'', '')


        page_no = int(page_no)
        page, new_list = cut_page(list)


        return render_template('content.html', docno=docno_rs, title=title_rs, ingres=ingres_rs, instrs=instrs_rs,
                               images=images_rs, links=links_rs, error=False, length=range(((page_no-1)*90),((page_no-1)*90)+len(new_list[page_no-1])),resultlen=resultlen,showlen=showlen, page=page, page_no=page_no, keys=keys)



    except:
        print("error")

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def get_dir(path):
    return render_template('error.html', error=True)



if __name__ == '__main__':
    app.run()


