import time
import os
import sched
from recipe_scrapers import scrape_me
import requests
from bs4 import BeautifulSoup
import csv
import re
import pandas as pd
from real_time_index import add_new_index
import threading
from search_tfidf import loadfile
import gc

# schedule = sched.scheduler(time.time, time.sleep)

# food.com

with open('start.txt', "r") as f:  # 设置文件对象
    start = int(f.read())  # 可以是随便对文件的操作
    print(start)
f.close()


def collect_new_data(start):
    k = start
    r = open('recipes.csv', 'r', encoding="utf-8")
    data = pd.read_csv(r)
    print(data.shape[0])
    df = pd.DataFrame(columns=('title', 'ingredients', 'instructions', 'image', 'links'))
    new_links_list = []
    # find new link from start to start+10
    for i in range(k, k + 10):
        link = 'https://www.food.com/recipe/' + str(i)
        html = requests.get(link)
        soup = BeautifulSoup(html.text, 'lxml')
        if soup.select('.recipe-nutrition__item'):
            new_links_list.append(link)
            start = i + 1
    print(new_links_list)
    # # if exist, remove, then scrape
    for link in new_links_list:
        if link not in data.values:
            print(link)
            scraper = scrape_me(link, wild_mode=True)
            title = scraper.title()
            ingredients = scraper.ingredients()
            instructions = scraper.instructions()
            image = scraper.image()
            df.loc[df.index.size] = [title, ingredients, instructions, image, link]
    # return start, df
    with open('start.txt', "w") as f:  # 设置文件对象
        f.write(str(start))
    f.close()

    return df


# food52.com
def get_food52_new():
    r = open('recipes.csv', 'r', encoding="utf-8")
    data = pd.read_csv(r)
    html = requests.get("https://food52.com/recipes/search?o=newest&page=1&tag=test-kitchen-approved")
    soup = BeautifulSoup(html.text, 'lxml')
    recipe_collection = soup.select('.photo-block a')
    new_food52 = pd.DataFrame(columns=('title', 'ingredients', 'instructions', 'image', 'links'))
    for i in range(0, len(recipe_collection)):
        # 用空格分开
        content = re.split(' ', str(recipe_collection[i]))
        # content[3]是含有url的那一项，content[3]一般格式为href="/recipes/85218-best-carrot-fritters-crecipe",通过正则表达读取数字
        result = re.findall("recipes/(.*?)-", content[3])
        # result带有引号和括号，用result[0]获得数字
        # print( result[0] )
        new_link = "https://food52.com/recipes/" + str(result[0])
        # print( new_link )
        if new_link not in data.values:
            scraper = scrape_me(new_link, wild_mode=True)
            title = scraper.title()
            ingredients = scraper.ingredients()
            instructions = scraper.instructions()
            image = scraper.image()
            new_food52 = new_food52.append(pd.DataFrame(
                {'title': [title], 'ingredients': [ingredients], 'instructions': [instructions], 'image': [image],
                 'links': [new_link]}), ignore_index=True)
    return new_food52


if __name__ == '__main__':
    new_food = collect_new_data(start)
    # print(new_start, new_food)
    new_food52 = get_food52_new()
    result = new_food.append(new_food52)
    # result = new_food
    # 如果有新数据
    if not result.empty:
        print('have collected new data')
        result.to_csv('new.csv', index=False)
        print("加")
        add_new_index()
        print("合并")


        print("重建recipe")


    else:
        print('no new data')

        print("jieshu")